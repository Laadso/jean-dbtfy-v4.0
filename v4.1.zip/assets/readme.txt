/*========= About Theme =========*/

Theme Name: Debutify
Theme URI: https://debutify.com

Author: Raphael Bergeron
Privacy Policy: https://debutify.com/privacy
Terms & conditions: https://debutify.com/terms

-------------------------------------------------------
Debutify theme, Copyright 2019 debutify.com
-------------------------------------------------------